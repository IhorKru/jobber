create function "RECRUITER_DATA_INSERT"()
  returns TABLE(recruiter_info_inserts integer, recruiter_additional_info_inserts integer, recruiter_login_details_inserts integer, recruiter_shopping_cart_details integer, recruiter_shopping_cart_user integer, recruiter_shopping_cart_contact integer, recruiter_shopping_cart_billing integer, recruiter_shopping_cart_abb integer)
language plpgsql
as $$
DECLARE
		recruiter_info_inserts integer;
		recruiter_additional_info_inserts integer;
		recruiter_login_details_inserts integer;
		recruiter_shopping_cart_details integer;
		recruiter_shopping_cart_user integer;
		recruiter_shopping_cart_contact integer;
		recruiter_shopping_cart_billing integer;
		recruiter_shopping_cart_abb integer;
		BEGIN
				--"MediaBay"."R_(01)_RecruiterDetails"
				INSERT INTO "MediaBay"."R_(01)_RecruiterDetails" (user_id, username, disabled, email_address, city, state_id, postal_code, country_id, date_created, channel_id, company_id, email_address_resumes, auto_user, edit_jobs, edit_user_profile, manage_company_job, manage_company_letter, manage_company_users,
				manage_corp_jobs, manage_corp_users, manage_jobs, manage_letters, pre_screen, post_jobs, search_resumes, max_recruiter_agents, date_expired, resume_format, first_name, last_name, address1, address2, daytime_phone, evening_phone, mobile_phone, fax, pager, confidential, company, career_level_id, available_time_id, available_day,
				available_month, available_year, location_id, date_modified, ats_permissions, middle_name, name_prefix_id, name_suffix, user_date_modified, resume_notes, resume_routing, application_resume_format, created_channel_id, recruiter_job_title, etl_date, datasource_id)
				SELECT DISTINCT ON (user_id) user_id, username, disabled, trim(both ' ' from email_address), initcap (trim(both ' ' from city)), state_id, trim(both ' ' from postal_code), country_id, date_created, channel_id, company_id, trim(both ' ' from email_address_resumes), auto_user, edit_jobs, edit_user_profile, manage_company_job, manage_company_letter, manage_company_users,
				manage_corp_jobs, manage_corp_users, manage_jobs, manage_letters, pre_screen, post_jobs, search_resumes, max_recruiter_agents, date_expired, resume_format, initcap (trim(both ' ' from first_name)), initcap (trim(both ' ' from last_name)), initcap (trim(both ' ' from address1)), initcap (trim(both ' ' from address2)), trim(both ' ' from daytime_phone), trim(both ' ' from evening_phone), 
				trim(both ' ' from mobile_phone), trim(both ' ' from fax), trim(both ' ' from pager), confidential, trim(both ' ' from company), career_level_id, available_time_id, available_day, available_month, available_year, location_id, date_modified, ats_permissions, initcap (trim(both ' ' from middle_name)), name_prefix_id, trim(both ' ' from name_suffix), user_date_modified, resume_notes, resume_routing, application_resume_format, created_channel_id, 
				initcap (trim(both ' ' from recruiter_job_title)), etl_date, datasource_id
				FROM "MediaBay"."R_STG_(01)_RecruiterDetails"
				ON CONFLICT DO NOTHING;
				GET DIAGNOSTICS recruiter_info_inserts = ROW_COUNT;
				--"MediaBay"."R_STG_(01.1)_RecruiterAdditionalInfo"
				DELETE FROM "MediaBay"."R_STG_(01.1)_RecruiterAdditionalInfo" ST WHERE NOT EXISTS (SELECT 1 FROM "MediaBay"."R_(01)_RecruiterDetails" RT WHERE ST.user_id = RT.user_id);
				INSERT INTO "MediaBay"."R_(01.1)_RecruiterAdditionalInfo" (user_id, company_id, job_function_id, skill_level_id, contact_preference_format_id, date_modified, datasource_id)
				SELECT DISTINCT ON (user_id) user_id, company_id, job_function_id, skill_level_id, contact_preference_format_id, date_modified, datasource_id
				FROM "MediaBay"."R_STG_(01.1)_RecruiterAdditionalInfo"
				ON CONFLICT DO NOTHING;
				GET DIAGNOSTICS recruiter_additional_info_inserts = ROW_COUNT;
				--"MediaBay"."R_STG_(01.2)_RecruiterLoginDetails"
				DELETE FROM "MediaBay"."R_STG_(01.2)_RecruiterLoginDetails" ST WHERE NOT EXISTS (SELECT 1 FROM "MediaBay"."R_(01)_RecruiterDetails" RT WHERE ST.user_id = RT.user_id);
				INSERT INTO "MediaBay"."R_(01.2)_RecruiterLoginDetails" (year, month_id, day_id, user_id, ip1, ip2, ip3, ip4, logins, school_id, webdate_id, datasource_id)
				SELECT DISTINCT ON (year, month_id, day_id, user_id, ip1, ip2, ip3, ip4) year, month_id, day_id, user_id, ip1, ip2, ip3, ip4, logins, school_id, webdate_id, datasource_id
				FROM "MediaBay"."R_STG_(01.2)_RecruiterLoginDetails"
				ON CONFLICT DO NOTHING;
				GET DIAGNOSTICS recruiter_login_details_inserts = ROW_COUNT;
				--"MediaBay"."R_(02)_RecruiterShoppingCartDetails"
				INSERT INTO "MediaBay"."R_(02)_RecruiterShoppingCartDetails" (cart_id, eorder_tax_amount, eorder_total_amount, po_number, paid, create_amount, member_shipin_cart, total_jobs_in_cart, total_resumes_in_cart, channel_id, abandoned_cart, date_created, date_modified, bill_back_info, datasource_id)
				SELECT DISTINCT ON (cart_id, datasource_id) cart_id, eorder_tax_amount, eorder_total_amount, po_number, paid, create_amount, member_shipin_cart, total_jobs_in_cart, total_resumes_in_cart, channel_id, abandoned_cart, date_created, date_modified, bill_back_info, datasource_id
				FROM "MediaBay"."R_STG_(02)_RecruiterShoppingCartDetails"
				ON CONFLICT DO NOTHING;
				GET DIAGNOSTICS recruiter_shopping_cart_details = ROW_COUNT;
				--"MediaBay"."R_(02.1)_RecruiterShoppingCartUser"
				DELETE FROM "MediaBay"."R_STG_(02.1)_RecruiterShoppingCartUser" ST WHERE NOT EXISTS (SELECT 1 FROM "MediaBay"."R_(02)_RecruiterShoppingCartDetails" RT WHERE ST.cart_id = RT.cart_id);
				INSERT INTO "MediaBay"."R_(02.1)_RecruiterShoppingCartUser" (user_id, channel_id, application_id, cart_id, datasource_id)
				SELECT DISTINCT ON (user_id, channel_id, application_id, cart_id, datasource_id) user_id, channel_id, application_id, cart_id, datasource_id
				FROM "MediaBay"."R_STG_(02.1)_RecruiterShoppingCartUser"
				ON CONFLICT DO NOTHING;
				GET DIAGNOSTICS recruiter_shopping_cart_user = ROW_COUNT;
				--"MediaBay"."R_(02.2)_RecruiterShoppingCartContact"
				DELETE FROM "MediaBay"."R_STG_(02.2)_RecruiterShoppingCartContact" ST WHERE NOT EXISTS (SELECT 1 FROM "MediaBay"."R_(02)_RecruiterShoppingCartDetails" RT WHERE ST.cart_id = RT.cart_id);
				INSERT INTO "MediaBay"."R_(02.2)_RecruiterShoppingCartContact" (cart_id, name_prefix_id, job_title, first_name, middle_name, last_name, company_name, address1, address2, email_address, city, state_id, zip_code, phone_number, fax_number, how_header_id, allow_marketing, date_created, date_modified, job_function_id, karma_company_size_id, company_id, datasource_id)
				SELECT DISTINCT ON (cart_id, datasource_id) cart_id, name_prefix_id, initcap(trim(both ' ' from job_title)), initcap(trim(both ' ' from first_name)), initcap(trim(both ' ' from middle_name)), initcap(trim(both ' ' from last_name)), trim(both ' ' from company_name), initcap(trim(both ' ' from address1)), initcap(trim(both ' ' from address2)), 
				trim(both ' ' from email_address), initcap (trim(both ' ' from city)), state_id, trim(both ' ' from zip_code), trim(both ' ' from phone_number), trim(both ' ' from fax_number), how_header_id, allow_marketing, date_created, date_modified, job_function_id, karma_company_size_id, company_id, datasource_id
				FROM "MediaBay"."R_STG_(02.2)_RecruiterShoppingCartContact"
				ON CONFLICT DO NOTHING;
				GET DIAGNOSTICS recruiter_shopping_cart_contact = ROW_COUNT;
				--"MediaBay"."R_(02.3)_RecruiterShoppingCartBilling"
				DELETE FROM "MediaBay"."R_STG_(02.3)_RecruiterShoppingCartBilling" ST WHERE NOT EXISTS (SELECT 1 FROM "MediaBay"."R_(02)_RecruiterShoppingCartDetails" RT WHERE ST.cart_id = RT.cart_id);
				INSERT INTO "MediaBay"."R_(02.3)_RecruiterShoppingCartBilling" (cart_id, name_prefix_id, first_name, middle_name, last_name, company, address1, address2, email_address, city, state_id, zip_code, phone_number, fax_number, po_number, payment_type_id, paypal_token, paypal_payer_id, bank_account_type_id, bank_routing_number, bank_account_number,split_billing, country_id, datasource_id)
				SELECT DISTINCT ON (cart_id, datasource_id) cart_id, name_prefix_id, initcap(trim(both ' ' from first_name)), initcap(trim(both ' ' from middle_name)), initcap(trim(both ' ' from last_name)), trim(both ' ' from company), initcap(trim(both ' ' from address1)), initcap(trim(both ' ' from address2)), trim(both ' ' from email_address), initcap(trim(both ' ' from city)), state_id, trim(both ' ' from zip_code), trim(both ' ' from phone_number), trim(both ' ' from fax_number), po_number, payment_type_id, paypal_token, paypal_payer_id, bank_account_type_id, bank_routing_number, bank_account_number,split_billing, country_id, datasource_id
				FROM "MediaBay"."R_STG_(02.3)_RecruiterShoppingCartBilling"
				ON CONFLICT DO NOTHING;
				GET DIAGNOSTICS recruiter_shopping_cart_billing = ROW_COUNT;
				--"MediaBay"."R_(02.4)_RecruiterAbandondShoppingCart"
				DELETE FROM "MediaBay"."R_STG_(02.4)_RecruiterAbandondShoppingCart" ST WHERE NOT EXISTS (SELECT 1 FROM "MediaBay"."R_(02)_RecruiterShoppingCartDetails" RT WHERE ST.cart_id = RT.cart_id);
				INSERT INTO "MediaBay"."R_(02.4)_RecruiterAbandondShoppingCart" (line_item_id, user_id, cart_id, channel_id, application_id, first_name, middle_name, last_name, company_name, address1, address2, email_address, company_id, date_expired, disabled, state_id,
				country_id, confidential, company, date_created, date_last_login, location_id, name_prefix_id, name_suffix, city, postal_code, daytime_phone, evening_phone, mobile_phone, fax, pager, date_modified, etl_date, datasource_id)
				SELECT DISTINCT ON (line_item_id, datasource_id) line_item_id, user_id, cart_id, channel_id, application_id, initcap(trim(both ' ' from first_name)), initcap(trim(both ' ' from middle_name)), initcap(trim(both ' ' from last_name)), trim(both ' ' from company_name), initcap(trim(both ' ' from address1)), initcap(trim(both ' ' from address2)), trim(both ' ' from email_address), company_id, date_expired, disabled, state_id,
				country_id, confidential, trim(both ' ' from company), date_created, date_last_login, location_id, name_prefix_id, trim(both ' ' from name_suffix), initcap(trim(both ' ' from city)), trim(both ' ' from postal_code), trim(both ' ' from daytime_phone), trim(both ' ' from evening_phone), trim(both ' ' from mobile_phone), trim(both ' ' from fax), trim(both ' ' from pager), date_modified, etl_date, datasource_id
				FROM "MediaBay"."R_STG_(02.4)_RecruiterAbandondShoppingCart"
				ON CONFLICT DO NOTHING;
				GET DIAGNOSTICS recruiter_shopping_cart_abb = ROW_COUNT;
				RETURN QUERY SELECT recruiter_info_inserts, recruiter_additional_info_inserts, recruiter_login_details_inserts, recruiter_shopping_cart_details, recruiter_shopping_cart_user, recruiter_shopping_cart_contact, recruiter_shopping_cart_billing, recruiter_shopping_cart_abb;
		END;

$$;

