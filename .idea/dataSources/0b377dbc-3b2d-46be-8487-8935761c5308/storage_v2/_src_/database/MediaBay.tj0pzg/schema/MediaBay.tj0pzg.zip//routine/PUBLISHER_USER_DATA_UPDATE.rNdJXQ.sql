create function "PUBLISHER_USER_DATA_UPDATE"()
  returns TABLE(publisher_guid_update integer, publisher_name_updates integer, commission_junction_pid_updates integer, date_modified_updates integer, etl_date_updates integer, publisher_email_address_updates integer, job_view_domain_channel_id_updates integer, cj_validated_updates integer, cjpid_updates integer, publisher_site_url_updates integer, publisher_site_desc_updates integer, publisher_site_status_id_updates integer, site_volume_id_updates integer, site_date_modified_updates integer, site_etl_date_updates integer, site_cjpid_updates integer)
language plpgsql
as $$
DECLARE
	--"MediaBay"."P_(01)_PublisherDetails"
	publisher_guid_update integer; publisher_name_updates integer; commission_junction_pid_updates integer; date_modified_updates integer; etl_date_updates integer; publisher_email_address_updates integer;
	job_view_domain_channel_id_updates integer; cj_validated_updates integer; cjpid_updates integer;
	--"MediaBay"."P_(02)_PublisherSiteDetails"
	publisher_site_url_updates integer; publisher_site_desc_updates integer; publisher_site_status_id_updates integer; site_volume_id_updates integer; site_date_modified_updates integer; site_etl_date_updates integer; site_cjpid_updates integer;
	BEGIN
		--"MediaBay"."P_(01)_PublisherDetails"--publisher_guid
		UPDATE "MediaBay"."P_(01)_PublisherDetails" RT
			SET publisher_guid = ST.publisher_guid
		FROM "MediaBay"."P_STG_(01)_PublisherDetails" ST
			WHERE
			RT.pubisher_id = ST.pubisher_id
			AND ST.publisher_guid <> RT.publisher_guid
			AND ST.publisher_guid <> '0'
			AND ST.publisher_guid IS NOT NULL;
		GET DIAGNOSTICS publisher_guid_update = ROW_COUNT;
		--"MediaBay"."P_(01)_PublisherDetails"--publisher_name
		UPDATE "MediaBay"."P_(01)_PublisherDetails" RT
			SET publisher_name = ST.publisher_name
		FROM "MediaBay"."P_STG_(01)_PublisherDetails" ST
			WHERE
			RT.pubisher_id = ST.pubisher_id
			AND ST.publisher_name <> RT.publisher_name
			AND ST.publisher_name <> '0'
			AND ST.publisher_name IS NOT NULL;
		GET DIAGNOSTICS publisher_name_updates = ROW_COUNT;
		--"MediaBay"."P_(01)_PublisherDetails"--commission_junction_pid
		UPDATE "MediaBay"."P_(01)_PublisherDetails" RT
			SET commission_junction_pid = ST.commission_junction_pid
		FROM "MediaBay"."P_STG_(01)_PublisherDetails" ST
			WHERE
			RT.pubisher_id = ST.pubisher_id
			AND ST.commission_junction_pid <> RT.commission_junction_pid
			AND ST.commission_junction_pid <> '0'
			AND ST.commission_junction_pid IS NOT NULL;
		GET DIAGNOSTICS commission_junction_pid_updates = ROW_COUNT;
		--"MediaBay"."P_(01)_PublisherDetails"--date_modified
		UPDATE "MediaBay"."P_(01)_PublisherDetails" RT
			SET date_modified = ST.date_modified
		FROM "MediaBay"."P_STG_(01)_PublisherDetails" ST
			WHERE
			RT.pubisher_id = ST.pubisher_id
			AND ST.date_modified <> RT.date_modified
			AND ST.date_modified IS NOT NULL;
		GET DIAGNOSTICS date_modified_updates = ROW_COUNT;
		--"MediaBay"."P_(01)_PublisherDetails"--etl_date
		UPDATE "MediaBay"."P_(01)_PublisherDetails" RT
			SET etl_date = ST.etl_date
		FROM "MediaBay"."P_STG_(01)_PublisherDetails" ST
			WHERE
			RT.pubisher_id = ST.pubisher_id
			AND ST.etl_date <> RT.etl_date
			AND ST.etl_date IS NOT NULL;
		GET DIAGNOSTICS etl_date_updates = ROW_COUNT;
		--"MediaBay"."P_(01)_PublisherDetails"--publisher_email_address
		UPDATE "MediaBay"."P_(01)_PublisherDetails" RT
			SET publisher_email_address = ST.publisher_email_address
		FROM "MediaBay"."P_STG_(01)_PublisherDetails" ST
			WHERE
			RT.pubisher_id = ST.pubisher_id
			AND ST.publisher_email_address <> RT.publisher_email_address
			AND ST.publisher_email_address <> '0'
			AND ST.publisher_email_address IS NOT NULL;
		GET DIAGNOSTICS publisher_email_address_updates = ROW_COUNT;
		--"MediaBay"."P_(01)_PublisherDetails"--job_view_domain_channel_id
		UPDATE "MediaBay"."P_(01)_PublisherDetails" RT
			SET job_view_domain_channel_id = ST.job_view_domain_channel_id
		FROM "MediaBay"."P_STG_(01)_PublisherDetails" ST
			WHERE
			RT.pubisher_id = ST.pubisher_id
			AND ST.job_view_domain_channel_id <> RT.job_view_domain_channel_id
			AND ST.job_view_domain_channel_id <> '0'
			AND ST.job_view_domain_channel_id IS NOT NULL;
		GET DIAGNOSTICS job_view_domain_channel_id_updates = ROW_COUNT;
		--"MediaBay"."P_(01)_PublisherDetails"--cj_validated
		UPDATE "MediaBay"."P_(01)_PublisherDetails" RT
			SET cj_validated = ST.cj_validated
		FROM "MediaBay"."P_STG_(01)_PublisherDetails" ST
			WHERE
			RT.pubisher_id = ST.pubisher_id
			AND ST.cj_validated <> RT.cj_validated
			AND ST.cj_validated <> '0'
			AND ST.cj_validated IS NOT NULL;
		GET DIAGNOSTICS cj_validated_updates = ROW_COUNT;
		--"MediaBay"."P_(01)_PublisherDetails"--cjpid
		UPDATE "MediaBay"."P_(01)_PublisherDetails" RT
			SET cjpid = ST.cjpid
		FROM "MediaBay"."P_STG_(01)_PublisherDetails" ST
			WHERE
			RT.pubisher_id = ST.pubisher_id
			AND ST.cjpid <> RT.cjpid
			AND ST.cjpid <> '0'
			AND ST.cjpid IS NOT NULL;
		GET DIAGNOSTICS cjpid_updates = ROW_COUNT;

----------"MediaBay"."P_(02)_PublisherSiteDetails"
		--"MediaBay"."P_(02)_PublisherSiteDetails"--publisher_site_url
		UPDATE "MediaBay"."P_(02)_PublisherSiteDetails" RT
			SET publisher_site_url = ST.publisher_site_url
		FROM "MediaBay"."P_STG_(02)_PublisherSiteDetails" ST
			WHERE
			RT.publisher_site_id = ST.publisher_site_id
			AND ST.publisher_site_url <> RT.publisher_site_url
			AND ST.publisher_site_url <> '0'
			AND ST.publisher_site_url IS NOT NULL;
		GET DIAGNOSTICS publisher_site_url_updates = ROW_COUNT;
		--"MediaBay"."P_(02)_PublisherSiteDetails"--publisher_site_desc
		UPDATE "MediaBay"."P_(02)_PublisherSiteDetails" RT
			SET publisher_site_desc = ST.publisher_site_desc
		FROM "MediaBay"."P_STG_(02)_PublisherSiteDetails" ST
			WHERE
			RT.publisher_site_id = ST.publisher_site_id
			AND ST.publisher_site_desc <> RT.publisher_site_desc
			AND ST.publisher_site_desc <> '0'
			AND ST.publisher_site_desc IS NOT NULL;
		GET DIAGNOSTICS publisher_site_desc_updates = ROW_COUNT;
		--"MediaBay"."P_(02)_PublisherSiteDetails"--publisher_site_status_id
		UPDATE "MediaBay"."P_(02)_PublisherSiteDetails" RT
			SET publisher_site_status_id = ST.publisher_site_status_id
		FROM "MediaBay"."P_STG_(02)_PublisherSiteDetails" ST
			WHERE
			RT.publisher_site_id = ST.publisher_site_id
			AND ST.publisher_site_status_id <> RT.publisher_site_status_id
			AND ST.publisher_site_status_id <> '0'
			AND ST.publisher_site_status_id IS NOT NULL;
		GET DIAGNOSTICS publisher_site_status_id_updates = ROW_COUNT;
		--"MediaBay"."P_(02)_PublisherSiteDetails"--site_volume_id
		UPDATE "MediaBay"."P_(02)_PublisherSiteDetails" RT
			SET site_volume_id = ST.site_volume_id
		FROM "MediaBay"."P_STG_(02)_PublisherSiteDetails" ST
			WHERE
			RT.publisher_site_id = ST.publisher_site_id
			AND ST.site_volume_id <> RT.site_volume_id
			AND ST.site_volume_id <> '0'
			AND ST.site_volume_id IS NOT NULL;
		GET DIAGNOSTICS site_volume_id_updates = ROW_COUNT;
		--"MediaBay"."P_(02)_PublisherSiteDetails"--date_modified
		UPDATE "MediaBay"."P_(02)_PublisherSiteDetails" RT
			SET date_modified = ST.date_modified
		FROM "MediaBay"."P_STG_(02)_PublisherSiteDetails" ST
			WHERE
			RT.publisher_site_id = ST.publisher_site_id
			AND ST.date_modified <> RT.date_modified
			AND ST.date_modified IS NOT NULL;
		GET DIAGNOSTICS site_date_modified_updates = ROW_COUNT;
		--"MediaBay"."P_(02)_PublisherSiteDetails"--etl_date
		UPDATE "MediaBay"."P_(02)_PublisherSiteDetails" RT
			SET etl_date = ST.etl_date
		FROM "MediaBay"."P_STG_(02)_PublisherSiteDetails" ST
			WHERE
			RT.publisher_site_id = ST.publisher_site_id
			AND ST.etl_date <> RT.etl_date
			AND ST.etl_date IS NOT NULL;
		GET DIAGNOSTICS site_etl_date_updates = ROW_COUNT;
		--"MediaBay"."P_(02)_PublisherSiteDetails"--cjpid
		UPDATE "MediaBay"."P_(02)_PublisherSiteDetails" RT
			SET cjpid = ST.cjpid
		FROM "MediaBay"."P_STG_(02)_PublisherSiteDetails" ST
			WHERE
			RT.publisher_site_id = ST.publisher_site_id
			AND ST.cjpid <> RT.cjpid
			AND ST.cjpid <> '0'
			AND ST.cjpid IS NOT NULL;
		GET DIAGNOSTICS site_cjpid_updates = ROW_COUNT;
			RETURN QUERY SELECT
			--"MediaBay"."P_(01)_PublisherDetails"
			publisher_guid_update, publisher_name_updates, commission_junction_pid_updates, date_modified_updates, etl_date_updates, publisher_email_address_updates,
			job_view_domain_channel_id_updates, cj_validated_updates, cjpid_updates,
			--"MediaBay"."P_(02)_PublisherSiteDetails"
			publisher_site_url_updates, publisher_site_desc_updates, publisher_site_status_id_updates, site_volume_id_updates, site_date_modified_updates, site_etl_date_updates, site_cjpid_updates;
	END;
$$;

